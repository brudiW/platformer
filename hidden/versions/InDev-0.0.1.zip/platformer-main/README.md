# platformer
out platformer


## Controller Mapping (Tested with XBox Controller):
### Left Stick:

- Left -> Right   - Axis 0
- Up   -> Down    - Axis 1
### Right Stick:

- Left -> Right   - Axis 2
- Up   -> Down    - Axis 3
### Left Trigger & Right Trigger:

- LT              - Axis 4
- RT              - Axis 5
### Buttons:

- A Button        - Button 0
- B Button        - Button 1
- X Button        - Button 2
- Y Button        - Button 3
- Left Bumper     - Button 4
- Right Bumper    - Button 5
- Back Button     - Button 6
- Start Button    - Button 7
- L. Stick In     - Button 8
- R. Stick In     - Button 9
### Hat/D-pad:

- Down -> Up      - Y Axis
- Left -> Right   - X Axis
